#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
============================================================================
 DESCARGA DE IMAGENES BIOMASS (ESA) - BANDA P - SEPARADO POR AOI
============================================================================
 Curso de posgrado - material didactico. 2026.

 Version standalone (para PC con Python). Para Colab, usa el cuaderno
 BIOMASS_Colab.ipynb de esta misma carpeta.

 QUE HACE
 --------
 1) Convierte tu TOKEN OFFLINE de la ESA en un access token (paso obligatorio).
 2) Busca en el catalogo STAC de ESA MAAP los productos BIOMASS que caen
    sobre cada AOI (BOSQUE_NW_02 y ESTEPA_NW_02), POR SEPARADO.
 3) Descarga cada AOI en su propia carpeta (Imagenes/<AOI>/<coleccion>/).

 REQUISITOS (una sola vez)
 -------------------------
   pip install pystac-client requests shapely
   Cuenta ESA "EO Sign In" + token offline generado en:
     https://portal.maap.eo.esa.int/ini/services/auth/token/  (Copy access token)

 NOTA sobre productos:
   - SCS  = Single-look Complex Slant-range (dato complejo de radar).
   - S1/S2/S3 = las tres franjas (swaths) que usa BIOMASS.
   - 1S = producto Standard (TRAE la imagen SAR).   <-- usar estos
   - 1M = producto Monitoring (version liviana SIN la imagen).
============================================================================
"""

import os
import requests
from pystac_client import Client
from shapely.geometry import Polygon

# ---------------------------------------------------------------------------
# 1) TU TOKEN OFFLINE  (pegalo entre las comillas)
# ---------------------------------------------------------------------------
OFFLINE_TOKEN = ""   # <-- PEGA AQUI tu token offline. Vacio = solo buscar (sin descargar)

# Datos oficiales del intercambio (ESA MAAP) - NO cambiar
TOKEN_URL     = "https://iam.maap.eo.esa.int/realms/esa-maap/protocol/openid-connect/token"
CLIENT_ID     = "offline-token"
CLIENT_SECRET = "p1eL7uonXs6MDxtGbgKdPVRAmnGxHpVE"

def obtener_access_token():
    """Convierte el token offline (90 dias) en un access token fresco (minutos)."""
    if not OFFLINE_TOKEN.strip():
        return ""
    r = requests.post(TOKEN_URL, data={
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "refresh_token",
        "refresh_token": OFFLINE_TOKEN.strip(),
        "scope": "offline_access openid",
    }, timeout=60)
    r.raise_for_status()
    return r.json()["access_token"]

ACCESS_TOKEN = obtener_access_token()
print("Access token OK." if ACCESS_TOKEN else "Sin token: solo BUSQUEDA (sin descarga).")

# ---------------------------------------------------------------------------
# 2) AOIs (lon, lat) tomados de los KML
# ---------------------------------------------------------------------------
AOIS = {
    "BOSQUE_NW_02": [
        (-71.5977324, -42.6912349), (-71.4147861, -42.6952402),
        (-71.4095719, -42.5602750), (-71.5921243, -42.5562884),
        (-71.5977324, -42.6912349)],
    "ESTEPA_NW_02": [
        (-71.2137477, -42.8433829), (-71.0303041, -42.8467842),
        (-71.0258965, -42.7117874), (-71.2089427, -42.7084021),
        (-71.2137477, -42.8433829)],
}

# ---------------------------------------------------------------------------
# 3) CONFIGURACION
# ---------------------------------------------------------------------------
CATALOG_URL = "https://catalog.maap.eo.esa.int/catalogue/"

# Fechas. Amplio para ver toda la cobertura disponible.
# ESTEPA tuvo datos en verano (feb 2026); BOSQUE en otono (abr-jun 2026).
FECHA_INICIO = "2025-09-01T00:00:00Z"
FECHA_FIN    = "2026-12-31T23:59:59Z"

COLECCIONES = ["BiomassLevel1a", "BiomassLevel1b", "BiomassLevel1c", "BiomassLevel2a"]
SALIDA = os.path.join(os.path.dirname(__file__), "..", "Imagenes")

DESCARGAR = True                 # True = descargar (necesita token)
SOLO_1S   = True                 # True = solo productos con imagen (1S)
MAX_POR_AOI = None               # None = todos; o un numero para probar (ej. 1)

# ---------------------------------------------------------------------------
# 4) FUNCIONES
# ---------------------------------------------------------------------------
def descargar_item(item, carpeta):
    """Descarga los assets del producto; renueva el access token si expira (401)."""
    global ACCESS_TOKEN
    os.makedirs(carpeta, exist_ok=True)
    for nombre_asset, asset in item.assets.items():
        destino = os.path.join(carpeta, f"{item.id}__{nombre_asset}")
        for intento in (1, 2):
            try:
                h = {"Authorization": f"Bearer {ACCESS_TOKEN}"}
                with requests.get(asset.href, headers=h, stream=True, timeout=600) as r:
                    if r.status_code == 401 and intento == 1:
                        ACCESS_TOKEN = obtener_access_token()   # renovar y reintentar
                        continue
                    r.raise_for_status()
                    with open(destino, "wb") as f:
                        for chunk in r.iter_content(chunk_size=1024 * 1024):
                            f.write(chunk)
                print("      OK ->", os.path.basename(destino))
                break
            except Exception as e:
                if intento == 2:
                    print("      ERROR", nombre_asset, ":", e)

def es_1S(item):
    """True si el producto es Standard (1S, con imagen)."""
    return "__1S" in item.id or "_1S_" in item.id

# ---------------------------------------------------------------------------
# 5) PRINCIPAL - separado por AOI
# ---------------------------------------------------------------------------
def main():
    catalogo = Client.open(CATALOG_URL)
    print("Conectado al catalogo STAC de ESA MAAP\n")

    for nombre, pts in AOIS.items():
        poly = Polygon(pts)
        minx, miny, maxx, maxy = poly.bounds
        bbox = [minx, miny, maxx, maxy]
        print(f"=== AOI: {nombre}  bbox={[round(v, 4) for v in bbox]} ===")

        for col in COLECCIONES:
            try:
                s = catalogo.search(collections=[col], bbox=bbox,
                                    datetime=[FECHA_INICIO, FECHA_FIN], max_items=300)
                items = list(s.items())
                if SOLO_1S:
                    items = [it for it in items if es_1S(it)]
                print(f"   {col}: {len(items)} producto(s)")

                if DESCARGAR and ACCESS_TOKEN:
                    sel = items if MAX_POR_AOI is None else items[:MAX_POR_AOI]
                    carpeta = os.path.join(SALIDA, nombre, col)
                    for it in sel:
                        print("     Descargando", it.id, "...")
                        descargar_item(it, carpeta)
            except Exception as e:
                print(f"   {col}: ERROR {e}")
        print()

    print("Listo. Archivos en:", os.path.abspath(SALIDA))

if __name__ == "__main__":
    main()

# Imagenes — KML, mapa y descargas

- `BOSQUE_NW_02.kml`, `ESTEPA_NW_02.kml` — las dos áreas de interés (AOI).
- `mapa_ubicacion_AOIs.png` — mapa de ubicación de ambas zonas.
- `BOSQUE_NW_02/` — descargas de BOSQUE (productos 1S de otoño 2026).
- `ESTEPA_NW_02/` — descargas de ESTEPA (productos 1S de verano 2026).

Las descargas se generan corriendo el cuaderno/script de `Script`
(o bajando desde el portal web). Ver `Informe/TUTORIAL_paso_a_paso.docx`.

Bounding boxes (de los KML):
| AOI          | lon_min  | lat_min  | lon_max  | lat_max  |
|--------------|----------|----------|----------|----------|
| BOSQUE_NW_02 | -71.5977 | -42.6952 | -71.4096 | -42.5563 |
| ESTEPA_NW_02 | -71.2137 | -42.8468 | -71.0259 | -42.7084 |

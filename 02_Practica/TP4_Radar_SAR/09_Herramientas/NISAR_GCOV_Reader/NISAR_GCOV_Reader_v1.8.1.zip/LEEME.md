# NISAR GCOV Reader — QGIS 3.44 y SNAP 14

Abre productos **NISAR GCOV (Nivel 2, HDF5)**. Es un paquete **separado**: no toca
el lector NISAR de Nivel 1 de SNAP ni ningún otro complemento de QGIS.

---

## Qué hay adentro

```
nisar_gcov_reader\        <- el complemento de QGIS (copiar entero)
    metadata.txt
    __init__.py
    nisar_gcov_plugin.py   (la ventana)
    nisar_gcov_core.py     (el lector: no depende de QGIS)
    nisar_gcov_cli.py      (mismo lector por línea de comandos)
    icon.png
GCOV_para_SNAP.bat         <- doble clic / arrastrar el .h5 encima
LEEME.md
```

---

## 1. Instalar en QGIS

Copiá la carpeta **`nisar_gcov_reader`** completa dentro de:

```
C:\Users\TU_USUARIO\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\
```

Después: QGIS → **Complementos → Administrar e instalar complementos → Instalados**
→ tildar **NISAR GCOV Reader**.

Queda un ícono en la barra y una entrada en **Ráster → NISAR GCOV → Abrir producto
NISAR GCOV…**

Uso: elegís el `.h5`, el complemento lista las grillas (`frequencyA`, `frequencyB`)
y las capas que hay adentro (HHHH, HVHV, VVVV… y las auxiliares `mask`,
`numberOfLooks`, `rtcGammaToSigmaFactor`). Marcás lo que querés, elegís dB o no,
y "Procesar". Los GeoTIFF quedan en la carpeta de salida y se cargan solos.

---

## 2. Abrir en SNAP 14

SNAP 14 no lee GCOV. En vez de tocar su lector de Nivel 1 (que anda), este paquete
**convierte el GCOV a BEAM-DIMAP**, que es el formato propio de SNAP:

1. Arrastrá el archivo `.h5` sobre **`GCOV_para_SNAP.bat`** (o ejecutalo y pegá la ruta).
2. Se genera `NOMBRE_frequencyA.dim` + carpeta `.data`.
3. En SNAP: **File → Open Product** → abrí el `.dim`.

Las bandas conservan su nombre (`HHHH_db`, `HVHV_db`, …), la proyección y el
tamaño de píxel. Desde ahí funcionan las herramientas normales de SNAP.

Si el `.dim` diera problema, usá la salida GeoTIFF: SNAP también la abre
(**File → Open Product**, elegís el `.tif`).

---

## 3. Línea de comandos (opcional)

Desde el **OSGeo4W Shell**:

```
python-qgis-ltr C:\ruta\nisar_gcov_reader\nisar_gcov_cli.py ARCHIVO.h5 --info
python-qgis-ltr ... nisar_gcov_cli.py ARCHIVO.h5 -o C:\salida --db
python-qgis-ltr ... nisar_gcov_cli.py ARCHIVO.h5 -o C:\salida --db --dimap
python-qgis-ltr ... nisar_gcov_cli.py ARCHIVO.h5 -o C:\salida --db --submuestreo 4
```

`--info` imprime la estructura interna del archivo: es lo primero que conviene
correr si algo no sale como se espera.

---

## Detalles que importan

- **Tamaño.** Un GCOV completo puede tener ~37.000 × 36.700 celdas: cada
  polarización pesa unos 5 GB en float32. Para clase o para una vista rápida usá
  el **submuestreo** (1 de cada 4 celdas → 16 veces menos). El diálogo muestra el
  tamaño estimado antes de procesar.
- **dB.** Se aplica `10*log10` solo a los términos de la diagonal (HHHH, HVHV,
  VVVV…), que son potencia gamma0. Los ceros y negativos quedan como NoData (NaN).
- **Dual, compacto y cuadripolar.** Los términos de la diagonal (HHHH, HVHV, VVVV…)
  salen como una capa cada uno. Los términos complejos fuera de la diagonal, que
  solo existen en productos cuadripolares, salen como **dos capas, `_real` e
  `_imag`**, porque un ráster de una banda no puede guardar un número complejo.
  Vienen destildados por omisión: si no vas a hacer polarimetría, no los necesitás.
- **Matriz C3 para SNAP** (solo cuadripolar). El tercer formato de salida escribe
  un BEAM-DIMAP con las bandas nombradas `C11, C12_real, C12_imag, C13_real,
  C13_imag, C22, C23_real, C23_imag, C33`, que es la nomenclatura con la que SNAP
  reconoce una matriz de covarianza y habilita las descomposiciones polarimétricas.
  Se escribe siempre en potencia lineal, nunca en dB.
  **Advertencia:** SNAP asume el vector de dispersión [HH, √2·HV, VV]. Si NISAR
  publica los términos sin ese factor √2, C22 y los términos cruzados quedan con
  un factor de escala distinto y las descomposiciones cuantitativas saldrían
  sesgadas. Antes de usarlo para medir, hay que verificar la convención en la
  especificación del producto. Para inspección visual y clasificación relativa no
  cambia nada.
- **Georreferencia.** Se arma con `xCoordinates`/`yCoordinates` (centro de celda,
  corregido a esquina) y el EPSG declarado en el dataset `projection`. Si el
  producto no declarara EPSG, el diálogo lo avisa y el ráster sale sin CRS.
- **Sin dependencias nuevas.** Usa el GDAL que ya trae QGIS (API multidimensional).
  Si hubiera `h5py` instalado lo aprovecha, pero no hace falta.

---

## Verificación hecha

Probado sobre un GCOV sintético con la misma estructura del producto real
(`/science/LSAR/GCOV/grids/frequencyA` con xCoordinates, yCoordinates,
projection/EPSG, HHHH, HVHV, VVVV, un término complejo y las capas auxiliares):

- estructura detectada correctamente, término complejo descartado;
- EPSG 32620 leído, GeoTransform y tamaño de píxel exactos;
- los dos caminos de lectura (GDAL y h5py) dan **valores idénticos**;
- GeoTIFF y BEAM-DIMAP dan **valores idénticos**;
- submuestreo 1/3 → tamaño de píxel 3× y grilla coherente.

Falta la prueba que solo se puede hacer en tu máquina: **el archivo GCOV real y la
apertura del `.dim` en SNAP 14**. Cuando lo bajes, corré primero `--info` y pasame
la salida.
